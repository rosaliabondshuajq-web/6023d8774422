// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("apple clang\n", stdout);
  return lionss_run_workload("apple-clang");
}
