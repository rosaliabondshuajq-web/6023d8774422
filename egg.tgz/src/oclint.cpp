// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("oclint\n", stdout);
  return lionss_run_workload("oclint");
}
