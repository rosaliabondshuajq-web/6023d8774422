// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("uclibc build"); }
int main(){
  announce();
  return lionss_run_workload("uclibc-build");
}
