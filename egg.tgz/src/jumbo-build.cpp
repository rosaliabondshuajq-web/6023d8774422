// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("jumbo build\n", stdout);
  return lionss_run_workload("jumbo-build");
}
